<?php
require_once (dirname(dirname(__FILE__)) . '/migxrecipesnutrition.class.php');
class migxrecipesNutrition_mysql extends migxrecipesNutrition {}