<?php
require_once (dirname(dirname(__FILE__)) . '/migxrecipesnutritiontranslation.class.php');
class migxrecipesNutritionTranslation_mysql extends migxrecipesNutritionTranslation {}