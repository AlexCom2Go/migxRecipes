<?php
class migxrecipesNutrition extends xPDOSimpleObject {}