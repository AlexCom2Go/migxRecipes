<?php
$xpdo_meta_map['migxrecipesNutrition']= array (
  'package' => 'migxrecipes',
  'version' => '1.1',
  'table' => 'migxrecipes_nutritions',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'name' => '',
  ),
  'fieldMeta' => 
  array (
    'name' => 
    array (
      'dbtype' => 'varchar',
      'phptype' => 'string',
      'precision' => '100',
      'null' => false,
      'default' => '',
    ),
  ),
);
