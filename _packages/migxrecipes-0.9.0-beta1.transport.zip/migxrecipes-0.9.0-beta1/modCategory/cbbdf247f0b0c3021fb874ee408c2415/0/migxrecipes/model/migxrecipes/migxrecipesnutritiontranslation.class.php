<?php
class migxrecipesNutritionTranslation extends xPDOSimpleObject {}