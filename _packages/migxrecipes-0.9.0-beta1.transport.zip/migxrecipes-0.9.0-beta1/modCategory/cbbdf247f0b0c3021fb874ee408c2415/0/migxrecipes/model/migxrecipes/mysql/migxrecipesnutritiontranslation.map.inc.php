<?php
$xpdo_meta_map['migxrecipesNutritionTranslation']= array (
  'package' => 'migxrecipes',
  'version' => '1.1',
  'table' => 'migxrecipes_nutrition_translations',
  'extends' => 'xPDOSimpleObject',
  'fields' => 
  array (
    'lang' => '',
    'caption' => '',
    'description' => '',
    'unit_text' => '',
  ),
  'fieldMeta' => 
  array (
    'lang' => 
    array (
      'dbtype' => 'varchar',
      'phptype' => 'string',
      'precision' => '3',
      'null' => false,
      'default' => '',
    ),
    'caption' => 
    array (
      'dbtype' => 'varchar',
      'phptype' => 'string',
      'precision' => '100',
      'null' => false,
      'default' => '',
    ),
    'description' => 
    array (
      'dbtype' => 'varchar',
      'phptype' => 'string',
      'precision' => '255',
      'null' => false,
      'default' => '',
    ),
    'unit_text' => 
    array (
      'dbtype' => 'varchar',
      'phptype' => 'string',
      'precision' => '100',
      'null' => false,
      'default' => '',
    ),
  ),
);
