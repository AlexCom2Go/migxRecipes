<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'migxrecipes-0.9.0-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '82ac69123ab54cfae1a6c619cb3a4db6',
      'native_key' => 'migxrecipes',
      'filename' => 'modNamespace/485f21a85d44f33aacb32f614743de8c.vehicle',
      'namespace' => 'migxrecipes',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '5187170d765587d2beecee24f5753643',
      'native_key' => 1,
      'filename' => 'modCategory/cbbdf247f0b0c3021fb874ee408c2415.vehicle',
      'namespace' => 'migxrecipes',
    ),
  ),
);